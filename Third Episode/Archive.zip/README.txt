FUNCTION main():
    Verify  the  CLI interface with -f filename and understandable usage messages.
    read the file: read_file(filename):

read_file(filename):
    set packets as empty list 
    open the file with with error exception in cade the file not exists
    Read all the lines if not lines return message "empty file" and exit.
    check if the file has headers
    if header skip the first line
    for each line :
        Parse line:
             check possible delimiters  and remove spaces
                get  the values and  cast them to integers: serialNo and priority
                 If they are no numeric ignore them , return none
                 if priority out of range (priority < o0 or priority>10) ignore the line , return none
        If line is valid the add it to packets list
     
    process the packets list in batches of 10
        - order each batch   by priority ASC, then serial ASC
        - print the batch (serial,priority)
        -continue with the nest batch






CLI example: python MiniFirewall -f input.csv 
  
output:
3,1
10,1
2,3
4,3
1,5
9,5
